./ ABSTERGO ID SENDER
./ Version : 1.4
./ By : Abstergo ID (fb.com/abstergo.id)
./ Coded in PHP

NEW ABSTERGO SENDER 1.4
WHAT'S NEW??

- Letter Rotating
- Smtp username tag
- Email username tag
- Fixed SMTPError "Data not accepted"
- More complex random api
- Expanded tags function
- Auto Generate Hexadecimal DKIM
- New clue added

[+] GENERAL USAGE

NEW
##emailuser## ( Get email username. Example : abstergo@yahoo.com become to 'abstergo' )
##usersmtp## ( Get smtp username )

============

##email## ( Email recepient )
##date## ( Generate date and time )
##domain## ( Smtp domain )
##link## ( Your link )
##imagecid## ( Your embedded image )
##useragent## ( Generate random user agent )
##ip## ( Generate random ip )
##os## ( Generate random os )
##device## ( Generate random device )
##country## ( Generate random country )

[+] RANDOM USAGE

BASIC ( 10 is your random string length and you can customize how long as you want )
##number_mix_10## ( Generate 10 random number )
##letter_mix_10## ( Generate 10 random letter mix UPPERCASE or lowercase)
##letter_up_10## ( Generate 10 random letter UPPERCASE )
##letter_low_10## ( Generate 10 random letter lowercase )
##letternumber_mix_10## ( Generate 10 random number and letter mix uppercase or lowercase )
##letternumber_up_10## ( Generate 10 random number and letter UPPERCASE )
##letternumber_low_10## ( Generate 10 random number and letter lowercase )

BLANK ( 1 is unique random id, you can customize 1-10 )
##blankbase1## ( Blank base64 encoded ) Example usage on Fromname & Subject : Pay##blankbase1##Pa##blankbase2##l
##blankquoted1## ( Blank quoted-printable encoded ) Example usage on Fromname & Subject : =?UTF-8?Q?Pay##blankquoted1##Pa##blankquoted2##l?=

BLANK FOR LETTER ( 1 is unique random id, you can customize 1-10 )
##blankletter1## Example usage on letter : Pay##blanklet1##Pa##blanklet2##l

MD5 STRING ( 1 is unique random id, you can customize 1-10 )
##randommd5_1##
Example :
##randommd5_1## = This is for unique random id (1)
##randommd5_3## = This is for unique random id (3)