<?php

/**
 ================================================
 + ABSTERGO SENDER - STILL LEARN TO BE PERFECTS +
 ================================================

 |==> + OUR TERMS OF USE +
 |
 |==> BY AGREEING TO THE TERMS OF USE, IT MEANS THAT YOU RELEASE ABSTERGO FROM ALL CLAIMS FOR USE
  |=> ABSTERGO IS NOT RESPONSIBLE FOR ANY USE OF THIS PRODUCT
  |=> THERE IS NO AGREEMENT FOR THE PURCHASE OF PRODUCTS FROM ABSTERGO THAT ALL ARE GUARANTEED OF LEGALITY
  |=> THESE TERMS OF USE ARE A LEGALLY BINDING AGREEMENT 
  |=> MADE BETWEEN YOU, EITHER PERSONALLY OR ON BEHALF OF AN ENTITY ("YOU") AND ABSTERGO ("US") 
  |=> REGARDING YOUR ACCESS TO AND USE OF ABSTERGO SENDER AS AN EMAIL SENDING TOOL OR RELATED APPLICATIONS, 
  |=> LINKED TO, OR CONNECTED TO THEM (COLLECTIVELY, "TOOLS"). 
  |=> YOU AGREE THAT BY USING THE TOOLS, YOU HAVE READ, UNDERSTOOD, AND AGREED TO BE BOUND BY ALL OF THESE TERMS OF USE.
  |=> IF YOU DO NOT AGREE WITH ALL OF THESE TERMS OF USE,
  |=> THEN YOU ARE EXPRESSLY PROHIBITED FROM USING THIS TOOL AND YOU MUST IMMEDIATELY STOP USING IT.

|==> + HOW TO USE +
 |
 |==> GET DEVICE ID FIRST 'php device.php' ON COMMAND LINE
 |==> LOGIN TO DASHBOARD AND ADD YOUR DEVICE ID
 |==> PUT YOUR LICENSE ON CONFIG
 |==> IF THERE IS A CONFIG THAT YOU DON'T USE THEN "LEAVE IT BLANK"

|==> + CLUE FOR YAHOO +
 |
 |==> USE RANDOM BLANK ON LETTER ( EXAMPLE : SEE DEFAULT SENDER LETTER )
 |==> USE RANDOM BLANK ON FROMNAME AND SUBJECT ( QUOTED OR BASE64 YOU HAVE TO CHOOSE BEST FOR YOU )
 |==> MAKE SURE YOUR SMTP DOMAIN HAVE A CORRECT SPF RECORD
 |==> ALWAYS USE RANDOM RETURN PATH
 |==> RECOMENDED TO ROTATE YOUR SMTP AS MUCH AS POSSIBLE WITH 1 CONNECTION ( EXAMPLE : ONE TAB SENDER FOR 10-20 SMTP ADMIN OR USER )
 |==> EACH USER OR ADMIN HAVE A DIFFERENT ORIGINATING IP, THAT'S WHY YOU NEED MANY ROTATING FOR WARMING UP THE ORIGINATING IP
 |==> USE GOOGLE GLOUD INSTANCE FOR SENDING ( IT'S VERY HELPFULL )
 |==> [NEW] YOUR DOMAIN MUST ALIVE
 |==> [NEW] USE CORPORATION DOMAIN ON FROM MAIL TO AVOID JUMPING ( EXAMPLE : RANDOM@INTEL.COM, RANDOM@TENCENT.COM )

|==> + CLUE FOR COMCAST AND OTHER +
 |
 |==> SAME CLUE LIKE YAHOO BUT HERE'S DIFFERENT
 |==> MAKE SURE YOUR SMTP DOMAIN IS ALIVE
 |==> DOMAIN SMTP MUST BE HAVE SPF AND DMARC RECORD
 |==> USE YOUR SMTP DOMAIN FOR FROM MAIL ( random@yoursmtpdomain / random@##domain## )
 |==> IF IT'S GOES TO SPAM/JUNK FOLDER THEN TRY TO CHANGE LETTER
 |==> AND IF STILL GOES TO SPAM/JUNK TRY TO CHANGE YOUR IP WITH VPN OR SOMETHING ( IT'S VERY HELPFULL )
**/

$smtp = 'smtp.txt'; // SMTP FILE

$listload = [
	'List'				=> 'list.txt', // LIST FILE
	'Clearduplicate'	=> false, // CLEAR DUPLICATE (true/false)
];

$abstergo_config = [
	'license' 			=> 'ABS-LS-FUCKED-BY-DNTHIRTEEN-L34KC0DE', // YOUR LICENSE KEY
	'Logfailed'			=> false, // LOG YOUR FAILED SEND MAILIST
	'color'				=> false, // CLI COLOR (true/false)
	'Host'				=> 'smtp-relay.gmail.com', // SMTP HOST
	'Port'				=> '587', // SMTP PORT
	'Hostname'			=> "mail-pf1-f".rand(100,999).".google.com", // CUSTOM HOSTNAME ( DON'T TOUCH IF U DON'T NOW WHAT IS THIS! )
	'Smtpsecure'		=> 'tls', // SMTP AUTH SECURE (tls/ssl)
	'Priority'			=> '3', // MAIL PRIORITY ( 1:high, 3:medium, 2:low )
	'Customreturnpath'	=> true, // CUSTOM RETURN PATH (true/false)
	'Returnpath'		=> 'msprvs1=##letternumber_mix_13##=bounces-##number_mix_6##-##number_mix_5##@##domain##', // RETURN PATH VALUE
	'Alternative'		=> true, // ALTERNATIVE LETTER PART (true/false)
	'Customalt'			=> true, // CUSTOM ALTERNATIVE LETTER PART (true/false)
	'Altfile'			=> 'Alt.txt', // ALTERNATIVE LETTER PART FILENAME
	'Addevent'			=> false, // iCalendar EVENT RANDOM GENERATOR (true/false) ( NOT WORK IF Embeddedimage IS ON!! )
	'Embeddedimage'		=> true, // EMBEDDED LOCAL IMAGE (true/false) ( GOOD FOR COMCAST AND OTHER )
	'Imagefile'			=> 'pp2.png', // EMBEDDED IMAGE FILENAME
	'Imagename'			=> 'Logo_##letternumber_low_10##.png', // EMBEDDED IMAGE CUSTOM NAME
	'Imagecid'			=> 'Logo_##letternumber_low_10##', // EMBEDDED IMAGE CUSTOM CID ( Example use on letter img src="##imagecid##" )
	'Customdkim'		=> true, // CUSTOM DKIM (true/false) ( NOT WORK ON GSUITE - USE AN OUTLOOK HEADER FOR GSUITE DKIM CUSTOMIZE )
	'Connection'		=> '1', // CONNECTION FOR SENDING
	'Delay'				=> '1', // SENDING DELAY ( SECOND )
	'Charset'			=> 'utf-8', // MAIL CHARSET ( us-ascii, iso-8859-1, utf-8)
	'Encoding'			=> 'quoted-printable', // MAIL ENCODING ( 7bit, 8bit, base64, binary, quoted-printable )
	'Link'				=> 'https://bing.com/##letternumber_mix_10##', // YOUR LINK ( Example use on letter href="##link##" )
	'Encryptlink'		=> false, // ENCRYPT LINK USING HTML ENTITIES ENCODING (true/false)
	'Randomparameter'	=> false,	// GENERATE RANDOM PARAMETER FOR YOUR LINK (true/false)
	'Header'			=> true, // CUSTOM HEADER (true/false)
	'Randomletter'		=> false, // RANDOM ALL LETTER SELECTION ON LETTER FOLDER
	'Randomattachment'	=> false, // RANDOM ALL ATTACHMENT SELECTION ON ATTACHMENT FOLDER
	'Encryptletter'		=> 'punycode', // CHANGE TEXT ON YOUR LETTER WITH ENCRYPTION ( unicode, unicodebold, unicodeitalic, htmlentities, punycode )
	'Encryptfromname'	=> '', // ( unicode, unicodebold, unicodeitalic, punycode ) ( DON'T USE THIS IF YOU USE RANDOM BLANK ON FROMNAME!! )
	'Encryptsubject'	=> '', // ( unicode, unicodebold, unicodeitalic, punycode ) ( DON'T USE THIS IF YOU USE RANDOM BLANK ON SUBJECT!! )
	'Dkimprivatevalue'	=> 'hexadecimal', // THIS IS DKIM KEY GENERATOR! DON'T TOUCH!!!
];

$abstergo_custom = [
		'##custom1##'	=> 'unicode|unicodebold|unicodeitalic|htmlentities|punycode',
		'##custom2##'	=> '7bit|8bit|base64|binary|quoted-printable',
		'##custom3##'	=> 'tencent.com|intel.com|oracle.com',
		'##custom4##'	=> 'value1|value2|value3|value4|value5',
		'##custom5##'	=> 'value1|value2|value3|value4|value5',
		'##custom6##'	=> 'value1|value2|value3|value4|value5',
		'##custom7##'	=> 'value1|value2|value3|value4|value5',
		'##custom8##'	=> 'value1|value2|value3|value4|value5',
		'##custom9##'	=> 'value1|value2|value3|value4|value5',
		'##custom10##'	=> 'value1|value2|value3|value4|value5',

]; // COSTUMIZE YOUR OWN RANDOM

$abstergo_send = [
[

	'Bccmode'			=> false, // BCC MODE (true/false)
	'To' 				=> '', // TO ( FOR BCC USE )
	'Fromname' 			=> '=?UTF-8?Q?ser##blankquoted4##vice-intl@pay##blankquoted3##pal##blankquoted1##.com?=', // FROM NAME
	'Frommail'			=> "##letternumber_mix_20##-##letternumber_mix_8##@##domain##", // FROM MAIL
	//'Subject' 			=> "[Secure##blankbase2## Report] Status : Account on ##blankbase3##hold##blankbase1## ID: ##letternumber_up_10##", // SUBJECT
	'Subject'			=> "[Secure##blankbase2## Report] - Login##blankbase3## from New ##blankbase2##Device, ID: ##letternumber_up_5##",
	'Attachmentfile'	=> '', // PDF FILE ( LEAVE IT BLANK IF NOT USE )
	'Attachmentname' 	=> "##letternumber_mix_10##.pdf", // PDF FILE CUSTOM NAME
	'Letter'			=> '1.html', // LETTER FILE
],
];


$abstergo_dkim =  array(
	'List-Unsubscribe|List-Help',
	'Campaign|Newsletter-ID',
); // DON'T TOUCH IF U DON'T NOW WHAT IS THIS!

$customable = base64_encode('{ "rcpt_to": "##email##", "tenant_id": "spc", "customer_id": "##number_mix_6##", "subaccount_id": "1", "message_id": "##letternumber_mix_20##" }'); // THIS IS MY CUSTOM VARIABLE TO ADD ON SOME CONFIG ( IF YOU NOT USING IT YOU CAN DELETE IT )

$abstergo_header = array(
	//"X-Mailer|WebService/1.1.18291 YMailNorrin Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
); // YOUR CUSTOM HEADER

?>